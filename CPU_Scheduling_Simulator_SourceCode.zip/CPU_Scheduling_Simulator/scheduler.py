"""
scheduler.py - Core CPU scheduling algorithms.

Each algorithm takes a list of Process objects and returns a Result containing
the Gantt chart (list of (pid, start, end) segments) and per-process metrics.
Lower priority number = higher priority.
"""
from dataclasses import dataclass, field
from collections import deque
from typing import List, Tuple

IDLE = "IDLE"


@dataclass
class Process:
    pid: str
    arrival: int
    burst: int
    priority: int = 0
    # filled in by the simulator
    remaining: int = field(init=False)
    start: int = field(default=-1, init=False)
    completion: int = field(default=0, init=False)

    def __post_init__(self):
        self.remaining = self.burst

    @property
    def turnaround(self) -> int:
        return self.completion - self.arrival

    @property
    def waiting(self) -> int:
        return self.turnaround - self.burst

    @property
    def response(self) -> int:
        return self.start - self.arrival


@dataclass
class Result:
    name: str
    gantt: List[Tuple[str, int, int]]
    processes: List[Process]

    def avg(self, attr: str) -> float:
        return sum(getattr(p, attr) for p in self.processes) / len(self.processes)

    @property
    def cpu_utilization(self) -> float:
        busy = sum(e - s for pid, s, e in self.gantt if pid != IDLE)
        total = self.gantt[-1][2] - self.gantt[0][1]
        return 100.0 * busy / total if total else 0.0

    @property
    def throughput(self) -> float:
        total = max(p.completion for p in self.processes) - min(p.arrival for p in self.processes)
        return len(self.processes) / total if total else 0.0


def _clone(procs: List[Process]) -> List[Process]:
    return [Process(p.pid, p.arrival, p.burst, p.priority) for p in procs]


def _add(gantt, pid, start, end):
    """Append a segment, merging with the previous one if it is the same pid."""
    if end <= start:
        return
    if gantt and gantt[-1][0] == pid and gantt[-1][2] == start:
        gantt[-1] = (pid, gantt[-1][1], end)
    else:
        gantt.append((pid, start, end))


def _validate(procs):
    if not procs:
        raise ValueError("Process list is empty")
    for p in procs:
        if p.burst <= 0 or p.arrival < 0:
            raise ValueError(f"Invalid process {p.pid}: burst must be > 0 and arrival >= 0")
    if len({p.pid for p in procs}) != len(procs):
        raise ValueError("Duplicate process IDs")


# ----------------------------------------------------------------------------
# Non-preemptive algorithms (FCFS, SJF, Priority share one engine)
# ----------------------------------------------------------------------------
def _non_preemptive(name, procs, key):
    _validate(procs)
    ps = _clone(procs)
    gantt, time, done = [], 0, 0
    while done < len(ps):
        ready = [p for p in ps if p.arrival <= time and p.remaining > 0]
        if not ready:
            nxt = min(p.arrival for p in ps if p.remaining > 0)
            _add(gantt, IDLE, time, nxt)
            time = nxt
            continue
        p = min(ready, key=key)
        p.start = time
        _add(gantt, p.pid, time, time + p.burst)
        time += p.burst
        p.remaining = 0
        p.completion = time
        done += 1
    return Result(name, gantt, ps)


def fcfs(procs):
    return _non_preemptive("FCFS", procs, key=lambda p: (p.arrival, p.pid))


def sjf(procs):
    return _non_preemptive("SJF (Non-preemptive)", procs, key=lambda p: (p.burst, p.arrival, p.pid))


def priority_np(procs):
    return _non_preemptive("Priority (Non-preemptive)", procs, key=lambda p: (p.priority, p.arrival, p.pid))


# ----------------------------------------------------------------------------
# Preemptive: SRTF (Shortest Remaining Time First)
# ----------------------------------------------------------------------------
def srtf(procs):
    _validate(procs)
    ps = _clone(procs)
    gantt, time, done = [], 0, 0
    while done < len(ps):
        ready = [p for p in ps if p.arrival <= time and p.remaining > 0]
        if not ready:
            nxt = min(p.arrival for p in ps if p.remaining > 0)
            _add(gantt, IDLE, time, nxt)
            time = nxt
            continue
        p = min(ready, key=lambda x: (x.remaining, x.arrival, x.pid))
        if p.start == -1:
            p.start = time
        _add(gantt, p.pid, time, time + 1)   # run one time unit
        p.remaining -= 1
        time += 1
        if p.remaining == 0:
            p.completion = time
            done += 1
    return Result("SRTF (Preemptive SJF)", gantt, ps)


# ----------------------------------------------------------------------------
# Round Robin
# ----------------------------------------------------------------------------
def round_robin(procs, quantum=2):
    _validate(procs)
    if quantum <= 0:
        raise ValueError("Quantum must be > 0")
    ps = sorted(_clone(procs), key=lambda p: (p.arrival, p.pid))
    gantt, time, done, i = [], 0, 0, 0
    queue = deque()
    while done < len(ps):
        while i < len(ps) and ps[i].arrival <= time:
            queue.append(ps[i]); i += 1
        if not queue:
            nxt = ps[i].arrival
            _add(gantt, IDLE, time, nxt)
            time = nxt
            continue
        p = queue.popleft()
        if p.start == -1:
            p.start = time
        run = min(quantum, p.remaining)
        _add(gantt, p.pid, time, time + run)
        time += run
        p.remaining -= run
        # processes that arrived while p was running go in BEFORE p is requeued
        while i < len(ps) and ps[i].arrival <= time:
            queue.append(ps[i]); i += 1
        if p.remaining == 0:
            p.completion = time
            done += 1
        else:
            queue.append(p)
    return Result(f"Round Robin (q={quantum})", gantt, ps)


ALGORITHMS = {
    "fcfs": fcfs,
    "sjf": sjf,
    "srtf": srtf,
    "priority": priority_np,
    "rr": round_robin,
}
