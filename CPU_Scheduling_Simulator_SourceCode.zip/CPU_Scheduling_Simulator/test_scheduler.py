import unittest
from scheduler import Process, fcfs, sjf, srtf, priority_np, round_robin, IDLE


def textbook():
    return [Process("P1", 0, 7, 2), Process("P2", 2, 4, 1),
            Process("P3", 4, 1, 3), Process("P4", 5, 4, 2)]


class TestSchedulers(unittest.TestCase):
    def wt(self, r):
        return {p.pid: p.waiting for p in r.processes}

    def test_fcfs(self):
        r = fcfs(textbook())
        self.assertEqual(self.wt(r), {"P1": 0, "P2": 5, "P3": 7, "P4": 7})

    def test_sjf(self):
        r = sjf(textbook())
        self.assertEqual(self.wt(r), {"P1": 0, "P2": 6, "P3": 3, "P4": 7})

    def test_srtf(self):
        r = srtf(textbook())
        self.assertEqual(self.wt(r), {"P1": 9, "P2": 1, "P3": 0, "P4": 2})
        self.assertAlmostEqual(r.avg("waiting"), 3.0)

    def test_round_robin(self):
        r = round_robin(textbook(), 2)
        self.assertEqual(sum(p.burst for p in r.processes), 16)
        self.assertEqual(max(p.completion for p in r.processes), 16)

    def test_priority(self):
        r = priority_np(textbook())
        self.assertEqual(r.gantt[0][0], "P1")      # only one ready at t=0
        self.assertEqual(r.gantt[1][0], "P2")      # priority 1 beats others

    def test_idle_gap(self):
        r = fcfs([Process("A", 0, 2), Process("B", 5, 2)])
        self.assertIn((IDLE, 2, 5), r.gantt)
        self.assertAlmostEqual(r.cpu_utilization, 4 / 7 * 100)

    def test_invalid(self):
        with self.assertRaises(ValueError):
            fcfs([Process("A", 0, 0)])
        with self.assertRaises(ValueError):
            round_robin(textbook(), 0)

    def test_metrics_identity(self):
        for algo in (fcfs, sjf, srtf, priority_np):
            for p in algo(textbook()).processes:
                self.assertEqual(p.turnaround, p.waiting + p.burst)


if __name__ == "__main__":
    unittest.main()
