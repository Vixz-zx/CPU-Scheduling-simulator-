# CPU Scheduling Simulator
Simulates FCFS, SJF, SRTF, Priority and Round Robin with Gantt charts and comparison graphs.

    pip install matplotlib numpy
    python main.py                      # built-in sample
    python main.py --quantum 4          # change RR quantum
    python main.py --file sample_processes.csv
    python -m unittest -v               # run tests
