"""
main.py - CLI + Gantt chart generator for the CPU Scheduling Simulator.

Usage:
    python main.py                 # run all algorithms on the built-in sample
    python main.py --quantum 3     # change Round Robin quantum
    python main.py --file procs.csv  # CSV columns: pid,arrival,burst,priority
    python main.py --no-plot       # text output only
"""
import argparse
import csv
import os

from scheduler import Process, Result, IDLE, fcfs, sjf, srtf, priority_np, round_robin

SAMPLE = [
    Process("P1", 0, 8, 3),
    Process("P2", 1, 4, 1),
    Process("P3", 2, 9, 4),
    Process("P4", 3, 5, 2),
    Process("P5", 12, 3, 5),   # arrives later, after the first batch
]


def load_csv(path):
    procs = []
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            procs.append(Process(row["pid"].strip(), int(row["arrival"]),
                                 int(row["burst"]), int(row.get("priority", 0) or 0)))
    return procs


def print_result(r: Result):
    print(f"\n=== {r.name} ===")
    print(f"{'PID':<5}{'AT':>4}{'BT':>4}{'PR':>4}{'CT':>5}{'TAT':>5}{'WT':>5}{'RT':>5}")
    for p in sorted(r.processes, key=lambda p: p.pid):
        print(f"{p.pid:<5}{p.arrival:>4}{p.burst:>4}{p.priority:>4}"
              f"{p.completion:>5}{p.turnaround:>5}{p.waiting:>5}{p.response:>5}")
    print(f"Avg TAT = {r.avg('turnaround'):.2f} | Avg WT = {r.avg('waiting'):.2f} | "
          f"Avg RT = {r.avg('response'):.2f}")
    print(f"CPU Utilization = {r.cpu_utilization:.1f}% | Throughput = {r.throughput:.3f} proc/unit")
    print("Gantt: " + " ".join(f"[{s}| {pid} |{e}]" for pid, s, e in r.gantt))


def plot_gantt(results, outdir):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    pids = sorted({p.pid for r in results for p in r.processes})
    cmap = plt.get_cmap("tab10")
    colors = {pid: cmap(i % 10) for i, pid in enumerate(pids)}
    colors[IDLE] = "#d9d9d9"

    # --- combined Gantt chart ---
    fig, axes = plt.subplots(len(results), 1, figsize=(10, 1.6 * len(results) + 0.8), sharex=True)
    for ax, r in zip(axes, results):
        for pid, s, e in r.gantt:
            ax.barh(0, e - s, left=s, color=colors[pid], edgecolor="black", height=0.6)
            ax.text((s + e) / 2, 0, pid if pid != IDLE else "idle", ha="center", va="center", fontsize=8)
        ax.set_yticks([])
        ax.set_ylabel(r.name, rotation=0, ha="right", va="center", fontsize=8)
        ax.grid(axis="x", linestyle=":", alpha=0.5)
    axes[-1].set_xlabel("Time units")
    fig.suptitle("Gantt Charts of CPU Scheduling Algorithms", fontweight="bold")
    fig.tight_layout()
    gpath = os.path.join(outdir, "gantt_charts.png")
    fig.savefig(gpath, dpi=150)
    plt.close(fig)

    # --- comparison bar chart ---
    import numpy as np
    names = [r.name.split(" (")[0] if "Round" not in r.name else r.name for r in results]
    x = np.arange(len(results)); w = 0.27
    fig, ax = plt.subplots(figsize=(10, 4.5))
    ax.bar(x - w, [r.avg("waiting") for r in results], w, label="Avg Waiting")
    ax.bar(x, [r.avg("turnaround") for r in results], w, label="Avg Turnaround")
    ax.bar(x + w, [r.avg("response") for r in results], w, label="Avg Response")
    ax.set_xticks(x); ax.set_xticklabels(names, fontsize=8)
    ax.set_ylabel("Time units"); ax.set_title("Algorithm Comparison", fontweight="bold")
    ax.legend(); ax.grid(axis="y", linestyle=":", alpha=0.5)
    fig.tight_layout()
    cpath = os.path.join(outdir, "comparison.png")
    fig.savefig(cpath, dpi=150)
    plt.close(fig)
    return gpath, cpath


def main():
    ap = argparse.ArgumentParser(description="CPU Scheduling Simulator")
    ap.add_argument("--file", help="CSV file with columns pid,arrival,burst,priority")
    ap.add_argument("--quantum", type=int, default=3, help="Round Robin time quantum")
    ap.add_argument("--outdir", default="output", help="Where charts are saved")
    ap.add_argument("--no-plot", action="store_true")
    args = ap.parse_args()

    procs = load_csv(args.file) if args.file else SAMPLE
    results = [fcfs(procs), sjf(procs), srtf(procs), priority_np(procs),
               round_robin(procs, args.quantum)]
    for r in results:
        print_result(r)

    best = min(results, key=lambda r: r.avg("waiting"))
    print(f"\n>>> Lowest average waiting time: {best.name} ({best.avg('waiting'):.2f})")

    if not args.no_plot:
        os.makedirs(args.outdir, exist_ok=True)
        g, c = plot_gantt(results, args.outdir)
        print(f"Charts saved: {g}, {c}")


if __name__ == "__main__":
    main()
