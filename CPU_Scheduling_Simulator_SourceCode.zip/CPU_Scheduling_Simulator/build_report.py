from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table,
                                TableStyle, Image, Preformatted, KeepTogether)
from html import escape

from scheduler import Process, fcfs, sjf, srtf, priority_np, round_robin
from main import SAMPLE

ss = getSampleStyleSheet()
body = ParagraphStyle("body", parent=ss["Normal"], fontSize=10.5, leading=15, alignment=TA_JUSTIFY, spaceAfter=6)
h1 = ParagraphStyle("h1", parent=ss["Heading1"], fontSize=16, textColor=colors.HexColor("#1F3A5F"), spaceBefore=10, spaceAfter=8, keepWithNext=1)
h2 = ParagraphStyle("h2", parent=ss["Heading2"], fontSize=12.5, textColor=colors.HexColor("#2E5C8A"), spaceBefore=8, spaceAfter=4)
title = ParagraphStyle("title", parent=ss["Title"], fontSize=26, leading=32, textColor=colors.HexColor("#1F3A5F"))
center = ParagraphStyle("center", parent=body, alignment=TA_CENTER, fontSize=12, leading=18)
code = ParagraphStyle("code", fontName="Courier", fontSize=6.8, leading=8.2)
bullet = ParagraphStyle("bullet", parent=body, leftIndent=14, bulletIndent=2, spaceAfter=2)

def P(t): return Paragraph(t, body)
def B(items): return [Paragraph(i, bullet, bulletText="\u2022") for i in items]

def tbl(data, widths=None, header=True):
    t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
    st = [("GRID", (0,0), (-1,-1), 0.5, colors.grey), ("FONTSIZE", (0,0), (-1,-1), 9),
          ("ALIGN", (0,0), (-1,-1), "CENTER"), ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
          ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#F2F6FA")])]
    if header:
        st += [("BACKGROUND", (0,0), (-1,0), colors.HexColor("#1F3A5F")),
               ("TEXTCOLOR", (0,0), (-1,0), colors.white), ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold")]
    t.setStyle(TableStyle(st)); return t

def footer(canvas, doc):
    canvas.saveState(); canvas.setFont("Helvetica", 8); canvas.setFillColor(colors.grey)
    canvas.drawCentredString(A4[0]/2, 1.2*cm, f"CPU Scheduling Simulator - Mini Project  |  Page {doc.page}")
    canvas.restoreState()

doc = SimpleDocTemplate("CPU_Scheduling_Simulator_Report.pdf", pagesize=A4,
                        leftMargin=2.2*cm, rightMargin=2.2*cm, topMargin=2*cm, bottomMargin=2*cm,
                        title="CPU Scheduling Simulator", author="Student")
S = []

# ---------- Title page ----------
S += [Spacer(1, 3.5*cm), Paragraph("CPU Scheduling Simulator", title),
      Paragraph("Visual Comparison of FCFS, SJF, SRTF, Priority and Round Robin Algorithms", center),
      Spacer(1, 1.2*cm), Paragraph("A Mini Project Report", center),
      Paragraph("Subject: Operating Systems", center), Spacer(1, 2*cm)]
S.append(tbl([["Submitted by", "[Your Name]"], ["Register No.", "[Your Reg. No.]"],
              ["Department", "[Your Department], B.E./B.Tech - III Year"],
              ["Guide", "[Faculty Name]"], ["Institution", "[Your University]"],
              ["Academic Year", "2026 - 2027"]], widths=[4.5*cm, 9*cm], header=False))
S.append(PageBreak())

# ---------- Abstract & Intro ----------
S += [Paragraph("Abstract", h1),
      P("CPU scheduling decides which process in the ready queue gets the processor and for how long. "
        "The choice of algorithm directly affects waiting time, turnaround time, response time and CPU utilization. "
        "This project implements a simulator in Python for five classical scheduling algorithms - First Come First Serve (FCFS), "
        "Shortest Job First (SJF), Shortest Remaining Time First (SRTF), Priority Scheduling and Round Robin (RR). "
        "Given a set of processes, the tool computes per-process metrics, prints a Gantt chart, produces comparison graphs and "
        "identifies the best algorithm for the workload. The implementation is validated with unit tests against hand-calculated textbook results."),
      Paragraph("1. Introduction", h1),
      P("In a multiprogramming operating system several processes compete for a single CPU. The short-term scheduler selects "
        "the next process from the ready queue. Understanding the trade-offs between algorithms is a core OS topic, but "
        "hand-drawing Gantt charts is slow and error-prone. A simulator makes it possible to experiment with different workloads instantly."),
      Paragraph("1.1 Objectives", h2)]
S += B(["Implement five scheduling algorithms with correct handling of arrival times and CPU idle gaps.",
        "Calculate Completion, Turnaround, Waiting and Response time for each process.",
        "Generate Gantt charts and comparison graphs automatically.",
        "Verify correctness through automated unit tests.",
        "Allow custom workloads through a CSV file and a configurable time quantum."])
S += [Paragraph("1.2 Scope and Tools", h2),
      P("Language: Python 3. Libraries: <i>matplotlib</i> and <i>numpy</i> for charts, <i>reportlab</i> for this report; the core "
        "scheduling logic uses only the standard library (<i>dataclasses</i>, <i>collections.deque</i>, <i>unittest</i>).")]

# ---------- Algorithms ----------
S += [Paragraph("2. Algorithms Implemented", h1)]
S.append(tbl([["Algorithm", "Type", "Selection rule", "Pros / Cons"],
    ["FCFS", "Non-preemptive", "Earliest arrival", "Simple; convoy effect"],
    ["SJF", "Non-preemptive", "Smallest burst time", "Low avg. wait; starvation"],
    ["SRTF", "Preemptive", "Smallest remaining time", "Optimal avg. wait; many switches"],
    ["Priority", "Non-preemptive", "Lowest priority number", "Flexible; starvation"],
    ["Round Robin", "Preemptive", "FIFO with time quantum", "Fair, good response; high TAT"]],
    widths=[3*cm, 3.2*cm, 4.3*cm, 5.2*cm]))
S += [Spacer(1, 6), Paragraph("2.1 Performance Metrics", h2)]
S += B(["<b>Turnaround Time (TAT)</b> = Completion Time - Arrival Time",
        "<b>Waiting Time (WT)</b> = Turnaround Time - Burst Time",
        "<b>Response Time (RT)</b> = First CPU time - Arrival Time",
        "<b>CPU Utilization</b> = (Busy time / Total time) x 100",
        "<b>Throughput</b> = Number of processes / Total time"])

# ---------- Design ----------
S += [Paragraph("3. System Design and Implementation", h1),
      P("The project is split into three modules so that logic, interface and verification stay independent."),
      tbl([["File", "Responsibility"],
           ["scheduler.py", "Process and Result data classes, the five algorithms, input validation"],
           ["main.py", "Command-line interface, CSV loader, text tables, Gantt and comparison plots"],
           ["test_scheduler.py", "8 unit tests checking waiting times, idle gaps and error handling"],
           ["build_report.py", "Generates this PDF report"]], widths=[4*cm, 12.5*cm]),
      Spacer(1, 8),
      Paragraph("3.1 Key Design Decisions", h2)]
S += B(["<b>Shared engine for non-preemptive algorithms:</b> FCFS, SJF and Priority differ only in the sort key, so one function "
        "takes the key as a parameter - this removes duplicate code.",
        "<b>Idle handling:</b> If no process has arrived, the clock jumps to the next arrival and an IDLE segment is recorded.",
        "<b>SRTF</b> is simulated one time unit at a time so that preemption on every new arrival is automatic.",
        "<b>Round Robin</b> enqueues processes that arrive during a time slice <i>before</i> re-queuing the preempted process, "
        "matching the standard textbook convention.",
        "<b>Gantt merging:</b> consecutive slices of the same process are merged into a single block.",
        "<b>Input validation:</b> bursts must be positive, IDs unique, quantum greater than zero."])

# ---------- Results ----------
procs = SAMPLE
results = [fcfs(procs), sjf(procs), srtf(procs), priority_np(procs), round_robin(procs, 3)]
S += [PageBreak(), Paragraph("4. Results and Analysis", h1),
      Paragraph("4.1 Input Workload", h2)]
S.append(tbl([["Process", "Arrival", "Burst", "Priority"]] + [[p.pid, p.arrival, p.burst, p.priority] for p in procs],
             widths=[3*cm, 3*cm, 3*cm, 3*cm]))
S += [Spacer(1, 8), Paragraph("4.2 Summary of Metrics", h2)]
rows = [["Algorithm", "Avg TAT", "Avg WT", "Avg RT", "CPU Util.", "Context switches"]]
for r in results:
    rows.append([r.name, f"{r.avg('turnaround'):.2f}", f"{r.avg('waiting'):.2f}", f"{r.avg('response'):.2f}",
                 f"{r.cpu_utilization:.0f}%", str(len(r.gantt) - 1)])
S.append(tbl(rows, widths=[5.2*cm, 2*cm, 2*cm, 2*cm, 2*cm, 3.2*cm]))
S += [Spacer(1, 8), Paragraph("4.3 Gantt Charts", h2),
      Image("output/gantt_charts.png", width=13*cm, height=13*cm*1320/1500),
      Spacer(1, 6)]
S += [PageBreak(), Paragraph("4.4 Algorithm Comparison", h2),
      Image("output/comparison.png", width=15.5*cm, height=15.5*cm*675/1500), Spacer(1, 8),
      Paragraph("4.5 Observations", h2)]
best = min(results, key=lambda r: r.avg("waiting"))
rr = results[-1]
S += B([f"<b>{best.name}</b> gave the lowest average waiting time ({best.avg('waiting'):.2f}), confirming that SRTF is "
        "provably optimal for average waiting time - at the cost of more context switches.",
        f"<b>Round Robin</b> had the best fairness - every process received the CPU early (average response time {rr.avg('response'):.2f}) - "
        f"but the highest average turnaround ({rr.avg('turnaround'):.2f}) because long jobs are repeatedly interrupted.",
        "<b>FCFS</b> suffers from the convoy effect: P3 (burst 9) delays all shorter jobs behind it.",
        "<b>Priority</b> scheduling favoured the urgent process P2 and P4, but P5 (lowest priority) waited until the end - an illustration of starvation risk.",
        "No single algorithm is best in all metrics; the right choice depends on whether the system values throughput, "
        "fairness or responsiveness (e.g. batch vs. interactive systems)."])

# ---------- Testing ----------
S += [Paragraph("5. Testing", h1),
      P("The simulator is verified with a classic textbook workload (P1: 0/7, P2: 2/4, P3: 4/1, P4: 5/4 as arrival/burst). "
        "Expected waiting times were calculated by hand and compared with program output.")]
S.append(tbl([["Test", "What it checks", "Result"],
    ["test_fcfs", "WT = {0, 5, 7, 7}", "Pass"], ["test_sjf", "WT = {0, 6, 3, 7}", "Pass"],
    ["test_srtf", "WT = {9, 1, 0, 2}, avg 3.0", "Pass"], ["test_round_robin", "Completion time = total burst", "Pass"],
    ["test_priority", "Highest priority picked first", "Pass"], ["test_idle_gap", "IDLE block and 57% utilization", "Pass"],
    ["test_invalid", "Errors for burst 0 / quantum 0", "Pass"], ["test_metrics_identity", "TAT = WT + BT for all", "Pass"]],
    widths=[4.5*cm, 8*cm, 3*cm]))

# ---------- Conclusion ----------
S += [Paragraph("6. Conclusion", h1),
      P("The simulator reproduces textbook scheduling behaviour accurately and makes the differences between algorithms "
        "visible through Gantt charts and comparison graphs. The project strengthened understanding of preemption, "
        "starvation, the convoy effect and the fairness-versus-efficiency trade-off."),
      Paragraph("7. Future Enhancements", h1)]
S += B(["Multilevel Queue and Multilevel Feedback Queue scheduling.", "Preemptive priority scheduling with aging to prevent starvation.",
        "Context-switch overhead and I/O burst modelling.", "A web or Tkinter GUI for entering processes interactively.",
        "Multi-core scheduling simulation."])
S += [Paragraph("8. How to Run", h1),
      Preformatted("pip install matplotlib numpy\npython main.py                   # run with built-in sample\n"
                   "python main.py --quantum 4       # change RR quantum\npython main.py --file sample_processes.csv\n"
                   "python -m unittest -v            # run tests", ParagraphStyle("c", fontName="Courier", fontSize=9, leading=12,
                   backColor=colors.HexColor("#F2F2F2"), borderPadding=6)),
      Paragraph("9. References", h1)]
S += B(["Silberschatz, Galvin, Gagne - <i>Operating System Concepts</i>, 10th Edition, Wiley.",
        "Tanenbaum, A. S. - <i>Modern Operating Systems</i>, 4th Edition, Pearson.",
        "Python Documentation - https://docs.python.org/3/",
        "Matplotlib Documentation - https://matplotlib.org/"])

# ---------- Appendix: source ----------
S.append(PageBreak()); S.append(Paragraph("Appendix A: Source Code - scheduler.py", h1))
S.append(Preformatted(open("scheduler.py").read(), code))
S.append(PageBreak()); S.append(Paragraph("Appendix B: Source Code - main.py", h1))
S.append(Preformatted(open("main.py").read(), code))
S.append(PageBreak()); S.append(Paragraph("Appendix C: Source Code - test_scheduler.py", h1))
S.append(Preformatted(open("test_scheduler.py").read(), code))
S.append(Spacer(1, 10)); S.append(Paragraph("Appendix D: Console Output", h1))
S.append(Preformatted(open("output_log.txt").read()[:3200], code))

doc.build(S, onFirstPage=footer, onLaterPages=footer)
print("done")
